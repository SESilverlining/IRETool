/**
 */
package nfr;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Positive Satisficing</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see nfr.NfrPackage#getPositiveSatisficing()
 * @model abstract="true"
 * @generated
 */
public interface PositiveSatisficing extends Satisficing {
} // PositiveSatisficing
