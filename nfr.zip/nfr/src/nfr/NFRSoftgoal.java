/**
 */
package nfr;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>NFR Softgoal</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see nfr.NfrPackage#getNFRSoftgoal()
 * @model
 * @generated
 */
public interface NFRSoftgoal extends SoftGoal {
} // NFRSoftgoal
