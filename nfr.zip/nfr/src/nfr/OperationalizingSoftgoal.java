/**
 */
package nfr;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Operationalizing Softgoal</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see nfr.NfrPackage#getOperationalizingSoftgoal()
 * @model
 * @generated
 */
public interface OperationalizingSoftgoal extends SoftGoal {
} // OperationalizingSoftgoal
