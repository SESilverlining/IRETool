/**
 */
package nfr;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Some Plus</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see nfr.NfrPackage#getSomePlus()
 * @model
 * @generated
 */
public interface SomePlus extends PositiveSatisficing {
} // SomePlus
