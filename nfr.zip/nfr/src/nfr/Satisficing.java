/**
 */
package nfr;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Satisficing</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see nfr.NfrPackage#getSatisficing()
 * @model abstract="true"
 * @generated
 */
public interface Satisficing extends Contribution {
} // Satisficing
