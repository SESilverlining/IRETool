/**
 */
package nfr;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Claim Softgoal</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see nfr.NfrPackage#getClaimSoftgoal()
 * @model
 * @generated
 */
public interface ClaimSoftgoal extends SoftGoal {
} // ClaimSoftgoal
