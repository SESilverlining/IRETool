/**
 */
package nfr.impl;

import nfr.NfrPackage;
import nfr.OperationalizingSoftgoal;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Operationalizing Softgoal</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class OperationalizingSoftgoalImpl extends SoftGoalImpl implements OperationalizingSoftgoal {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected OperationalizingSoftgoalImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return NfrPackage.Literals.OPERATIONALIZING_SOFTGOAL;
	}

} //OperationalizingSoftgoalImpl
