/**
 */
package nfr.impl;

import nfr.NfrPackage;
import nfr.PositiveSatisficing;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Positive Satisficing</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public abstract class PositiveSatisficingImpl extends SatisficingImpl implements PositiveSatisficing {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PositiveSatisficingImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return NfrPackage.Literals.POSITIVE_SATISFICING;
	}

} //PositiveSatisficingImpl
