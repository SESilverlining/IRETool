/**
 */
package nfr;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>OR Decomposition</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see nfr.NfrPackage#getORDecomposition()
 * @model
 * @generated
 */
public interface ORDecomposition extends Decomposition {
} // ORDecomposition
