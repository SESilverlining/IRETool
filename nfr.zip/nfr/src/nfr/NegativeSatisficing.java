/**
 */
package nfr;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Negative Satisficing</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see nfr.NfrPackage#getNegativeSatisficing()
 * @model abstract="true"
 * @generated
 */
public interface NegativeSatisficing extends Satisficing {
} // NegativeSatisficing
