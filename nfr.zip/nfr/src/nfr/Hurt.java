/**
 */
package nfr;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Hurt</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see nfr.NfrPackage#getHurt()
 * @model
 * @generated
 */
public interface Hurt extends NegativeSatisficing {
} // Hurt
