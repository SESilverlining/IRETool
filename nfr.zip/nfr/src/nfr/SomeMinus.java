/**
 */
package nfr;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Some Minus</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see nfr.NfrPackage#getSomeMinus()
 * @model
 * @generated
 */
public interface SomeMinus extends NegativeSatisficing {
} // SomeMinus
