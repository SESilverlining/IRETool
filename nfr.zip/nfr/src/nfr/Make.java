/**
 */
package nfr;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Make</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see nfr.NfrPackage#getMake()
 * @model
 * @generated
 */
public interface Make extends PositiveSatisficing {
} // Make
