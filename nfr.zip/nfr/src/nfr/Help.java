/**
 */
package nfr;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Help</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see nfr.NfrPackage#getHelp()
 * @model
 * @generated
 */
public interface Help extends PositiveSatisficing {
} // Help
