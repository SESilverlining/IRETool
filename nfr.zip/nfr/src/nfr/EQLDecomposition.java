/**
 */
package nfr;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>EQL Decomposition</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see nfr.NfrPackage#getEQLDecomposition()
 * @model
 * @generated
 */
public interface EQLDecomposition extends Decomposition {
} // EQLDecomposition
