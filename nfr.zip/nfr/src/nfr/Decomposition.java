/**
 */
package nfr;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Decomposition</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see nfr.NfrPackage#getDecomposition()
 * @model abstract="true"
 * @generated
 */
public interface Decomposition extends Contribution {
} // Decomposition
