/**
 */
package nfr;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>AND Decomposition</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see nfr.NfrPackage#getANDDecomposition()
 * @model
 * @generated
 */
public interface ANDDecomposition extends Decomposition {
} // ANDDecomposition
