/**
 */
package nfr;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Break</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see nfr.NfrPackage#getBreak()
 * @model
 * @generated
 */
public interface Break extends NegativeSatisficing {
} // Break
